/**
 * 
 */
/**
 * 
 */
module RentalCars {
	requires java.desktop;
}